package com.goat.attendance;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.widget.Toast;
import androidx.appcompat.widget.SearchView;
import org.json.JSONArray;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private MainBinding binding;

    private ArrayList<HashMap<String, Object>> students = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> filteredStudents = new ArrayList<>();
    private ArrayList<String> Students_lst = new ArrayList<>();
    private Listview1Adapter adapter;

    private static TableAPI table;

    private Intent intentt = new Intent();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = MainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setTitle("Studence List");

        initialize();
        initializeLogic();
    }

    private void saveData() {

        FileUtil.writeFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/students.json"), new Gson().toJson(students));
    }

    private void saveStudents() {
        FileUtil.writeFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/list_students.json"), new Gson().toJson(Students_lst));
    }

    private void loadStudents() {
        String path = FileUtil.getPackageDataDir(getApplicationContext())
                .concat("/list_students.json");

        String json = FileUtil.readFile(path);

        if (json == null || json.trim().isEmpty()) {
            Students_lst = new ArrayList<>();
            return;
        }

        try {
            Students_lst = new Gson().fromJson(json, new TypeToken<
                            ArrayList<String>>() {}.getType());

            if (Students_lst == null) {
                Students_lst = new ArrayList<>();
            }

        } catch (Exception e) {
            Students_lst = new ArrayList<>();
        }
    }

    private void loadData() {

        String path = FileUtil.getPackageDataDir(getApplicationContext()).concat("/students.json");

        String json = FileUtil.readFile(path);

        if (json == null || json.trim().isEmpty()) {
            students = new ArrayList<>();
            return;
        }

        try {
            students = new Gson().fromJson(
                            json,
                            new TypeToken<ArrayList<HashMap<String, Object>>>() {}.getType()
                    );

            if (students == null) {
                students = new ArrayList<>();
            }

        } catch (Exception e) {
            students = new ArrayList<>();
        }
    }

    private void initialize() {

        setSupportActionBar(binding.Toolbar);

        binding.Toolbar.setNavigationOnClickListener(v -> onBackPressed());

        binding.Fab.setOnClickListener(v -> {
            DialogDialogFragmentActivity dialog = new DialogDialogFragmentActivity();

            dialog.setDialogListener(new DialogDialogFragmentActivity.DialogListener() {
                @Override
                public void onDialogResult(Bundle data) {

                    HashMap<String, Object> usr = new HashMap<>();

                    usr.put("name", data.getString("name"));
                    usr.put("place", data.getString("place"));
                    usr.put("number", data.getString("phone"));
                    usr.put("img_uri", "");
                    usr.put("isPresent", true);

                    students.add(usr);
                    Students_lst.add(data.getString("name"));
                    String name = data.getString("name");

                    addRowTable(name, table.getTotalColumns());

                    saveData();
                    saveStudents();

                    filteredStudents.clear();
                    filteredStudents.addAll(students);

                    adapter.notifyDataSetChanged();
                }
            });
            dialog.show(getSupportFragmentManager(), "dialog");
        });

        binding.listview1.setAdapter(new Listview1Adapter(students));

        ((BaseAdapter) binding.listview1.getAdapter()).notifyDataSetChanged();

        binding.searchview1.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterList(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return true;
            }
        });
    }

    private void addRowTable(String rowName, int size) {
        JSONArray row = new JSONArray();
        row.put(rowName);
        for (int i = 0; i < size; i++) {
            row.put("0");
        }
        table.addRow(row.toString());
    }

    private void deleteRowTable(String name) {
        int index = table.findRowByName(name);
        table.deleteRow(index);
    }

    private void reloadTable() {
        while (table.getTotalRows() < Students_lst.size()) {
            String name = Students_lst.get(table.getTotalRows());
            addRowTable(name, table.getTotalColumns());
        }
    }

    private void initializeLogic() {

        table = TableManager.getTable();
        Students_lst.clear();
        loadStudents();
        reloadTable();
        loadData(); // FIRST load data

        if (students == null || students.size() == 0) {
            students = new ArrayList<>();
            HashMap<String, Object> u1 = new HashMap<>();
            u1.put("name", "Student");
            u1.put("place", "Chennai");
            u1.put("number", "999999");
            u1.put("img_uri", "");
            u1.put("isPresent", true);
            Students_lst.add("Student");
            students.add(u1);

            /*
            HashMap<String, Object> u2 = new HashMap<>();
            u2.put("name", "Melson");
            u2.put("place", "Vembar");
            u2.put("number", "999998");
            u2.put("img_uri", "");
            u2.put("isPresent", true);
            students.add(u2);
            Students_lst.add("Melson");
            */
            saveData();
            saveStudents();
            reloadTable();
        }

        filteredStudents.clear();
        filteredStudents.addAll(students);

        adapter = new Listview1Adapter(filteredStudents);
        binding.listview1.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    private void updateList() {
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    private void filterList(String keyword) {

        filteredStudents.clear();

        if (keyword == null || keyword.trim().isEmpty()) {

            filteredStudents.addAll(students);

        } else {

            keyword = keyword.toLowerCase().trim();

            for (HashMap<String, Object> item : students) {

                String name = String.valueOf(item.get("name"))
                        .toLowerCase();

                String place = String.valueOf(item.get("place"))
                        .toLowerCase();

                String number = String.valueOf(item.get("number"))
                        .toLowerCase();

                if (name.contains(keyword)
                        || place.contains(keyword)
                        || number.contains(keyword)) {

                    filteredStudents.add(item);
                }
            }
        }

        adapter.notifyDataSetChanged();
    }

    private void showFloatingMenu(int x, int y, int position) {

        View popupView = getLayoutInflater().inflate(R.layout.popup_options, null);

        PopupWindow popupWindow = new PopupWindow(
        popupView,
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
        true
        );

        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);

        TextView edit = popupView.findViewById(R.id.edit);
        TextView delete = popupView.findViewById(R.id.delete);
        TextView qrcode = popupView.findViewById(R.id.qrcode);

        edit.setOnClickListener(v -> {
            popupWindow.dismiss();

            Toast.makeText(
                    MainActivity.this,
                    "Edit clicked",
                    Toast.LENGTH_SHORT
            ).show();

            // TODO: Edit student
        });

        delete.setOnClickListener(v -> {
            popupWindow.dismiss();

            HashMap<String, Object> selected = filteredStudents.get(position);

            students.remove(selected);
            filteredStudents.remove(position);
            String name = String.valueOf(selected.get("name"));
            Students_lst.remove(name);
            // table.deleteRow(table.getTotalRows());
            deleteRowTable(name);

            updateList();
            saveData();
            saveStudents();
            reloadTable();

            Toast.makeText(
                    MainActivity.this,
                    "Student deleted",
                    Toast.LENGTH_SHORT
            ).show();
        });

        qrcode.setOnClickListener(v -> {
            popupWindow.dismiss();

            HashMap<String, Object> student = filteredStudents.get(position);

            String qrText = "UserName: " +
                    String.valueOf(student.get("name"));

            Intent qrIntent = new Intent(
            MainActivity.this,
            QrviewerActivity.class
            );

            qrIntent.putExtra("qr_data", qrText);

            startActivity(qrIntent);
        });

        popupView.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        );

        int popupW = popupView.getMeasuredWidth();
        int popupH = popupView.getMeasuredHeight();

        int screenW = getResources().getDisplayMetrics().widthPixels;

        int posX = x - (popupW / 2);
        int posY = y - popupH - 50;

        if (posX < 0) {
            posX = 20;
        }

        if (posX + popupW > screenW) {
            posX = screenW - popupW - 20;
        }

        if (posY < 0) {
            posY = y + 50;
        }

        popupWindow.showAtLocation(
                binding.getRoot(),
                android.view.Gravity.NO_GRAVITY,
                posX,
                posY
        );

        popupView.setAlpha(0f);
        popupView.setScaleX(0.9f);
        popupView.setScaleY(0.9f);

        popupView.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(150)
                .start();
    }

    public class Listview1Adapter extends BaseAdapter {

        ArrayList<HashMap<String, Object>> _data;

        public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
            _data = _arr;
        }

        @Override
        public int getCount() {
            return _data.size();
        }

        @Override
        public Object getItem(int position) {
            return _data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            RowBinding row = RowBinding.inflate(getLayoutInflater());

            HashMap<String, Object> item = _data.get(position);

            String name = String.valueOf(item.get("name"));
            String place = String.valueOf(item.get("place"));
            String number = String.valueOf(item.get("number"));

            row.userName.setText("null".equals(name) ? "" : name);
            row.userPlc.setText("null".equals(place) ? "" : place);
            row.userNum.setText("null".equals(number) ? "" : number);

            boolean present = false;
            Object p = item.get("isPresent");

            if (p instanceof Boolean) {
                present = (Boolean) p;
            } else if (p != null) {
                present = Boolean.parseBoolean(String.valueOf(p));
            }

            if (present) {
                row.userAtt.setText("Present");
                row.userAtt.setTextColor(0xFF388E3C);
            } else {
                row.userAtt.setText("Absent");
                row.userAtt.setTextColor(0xFFE53935);
            }

            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(999);
            bg.setStroke(2, 0xFF000000);
            bg.setColor(Color.TRANSPARENT);

            row.imgBack.setBackground(bg);

            row.getRoot().setOnLongClickListener(v -> {
                int[] loc = new int[2];
                v.getLocationOnScreen(loc);

                float x = loc[0] + v.getWidth() / 2f;
                float y = loc[1] + v.getHeight() / 2f;

                showFloatingMenu((int) x, (int) y, position);

                return true;
            });

            return row.getRoot();
        }
    }
}
