package com.goat.attendance;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.HorizontalScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;

public class TableActivity extends AppCompatActivity {
	
	TableLayout headerTable, bodyTable;
	HorizontalScrollView headerScroll, bodyScroll;
	
	final int COL_WIDTH  = 40;
	final int NAME_WIDTH = 60;
	final int ROW_HEIGHT = 18;
	
	String jsonData = "{"
	+ "\"days\":[\"Day 1\",\"Day 2\",\"Day 3\",\"Day 4\",\"Day 5\"],"
	+ "\"students\":["
	+ "{\"name\":\"Alice\", \"attendance\":[1,1,0,1,1]},"
	+ "{\"name\":\"Bob\",   \"attendance\":[1,0,0,1,1]},"
	+ "{\"name\":\"Carol\", \"attendance\":[0,1,1,1,0]},"
	+ "{\"name\":\"David\", \"attendance\":[1,1,1,1,1]}"
	+ "]}";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.table);
		
		headerTable  = findViewById(R.id.headerTable);
		bodyTable    = findViewById(R.id.bodyTable);
		headerScroll = findViewById(R.id.headerScroll);
		bodyScroll   = findViewById(R.id.bodyScroll);
		
		jsonData = getIntent().getStringExtra("jsondata");
		
		// Sync header scroll with body scroll
		bodyScroll.getViewTreeObserver().addOnScrollChangedListener(() ->
		headerScroll.scrollTo(bodyScroll.getScrollX(), 0));
		
		loadTable();
	}
	
	
	private void loadTable() {
		try {
			JSONObject root     = new JSONObject(jsonData);
			JSONArray  days     = root.getJSONArray("days");
			JSONArray  students = root.getJSONArray("students");
			
			// ── Header row ───────────────────────────────────────
			TableRow headerRow = new TableRow(this);
			headerRow.setBackgroundColor(Color.parseColor("#1565C0"));
			
			headerRow.addView(makeCell("Name", NAME_WIDTH, true, Color.WHITE));
			
			for (int d = 0; d < days.length(); d++) {
				headerRow.addView(makeCell(days.getString(d), COL_WIDTH, true, Color.WHITE));
			}
			
			headerRow.addView(makeCell("%", COL_WIDTH, true, Color.WHITE));
			
			headerTable.addView(headerRow);
			
			// ── Data rows ────────────────────────────────────────
			for (int i = 0; i < students.length(); i++) {
				JSONObject student    = students.getJSONObject(i);
				JSONArray  attendance = student.getJSONArray("attendance");
				
				TableRow row = new TableRow(this);
				row.setBackgroundColor(i % 2 == 0
				? Color.WHITE
				: Color.parseColor("#E3F2FD"));
				
				// Name cell
				row.addView(makeCell(student.getString("name"), NAME_WIDTH, false, Color.BLACK));
				
				// P / A cells
				int presentCount = 0;
				for (int d = 0; d < attendance.length(); d++) {
					int val = attendance.getInt(d);
					if (val == 1) presentCount++;
					
					String label     = (val == 1) ? "P" : "A";
					int    textColor = (val == 1)
					? Color.parseColor("#2E7D32")  // green - Present
					: Color.parseColor("#C62828"); // red   - Absent
					
					row.addView(makeCell(label, COL_WIDTH, false, textColor));
				}
				
				// Percentage cell
				int percentage = (int) Math.round((presentCount * 100.0) / attendance.length());
				
				int pctColor;
				if (percentage >= 75)      pctColor = Color.parseColor("#2E7D32"); // green
				else if (percentage >= 50) pctColor = Color.parseColor("#F57F17"); // amber
				else                       pctColor = Color.parseColor("#C62828"); // red
				
				row.addView(makeCell(percentage + "%", COL_WIDTH, true, pctColor));
				
				bodyTable.addView(row);
				
				// Divider
				android.view.View div = new android.view.View(this);
				div.setLayoutParams(new TableLayout.LayoutParams(
				TableLayout.LayoutParams.MATCH_PARENT, 1));
				div.setBackgroundColor(Color.parseColor("#BBDEFB"));
				bodyTable.addView(div);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private TextView makeCell(String text, int widthDp, boolean bold, int textColor) {
		TextView tv = new TextView(this);
		tv.setText(text);
		tv.setTextColor(textColor);
		tv.setTextSize(12f);
		tv.setGravity(Gravity.CENTER);
		tv.setPadding(6, 0, 6, 0);
		
		// Cell border
		android.graphics.drawable.GradientDrawable border =
		new android.graphics.drawable.GradientDrawable();
		border.setColor(Color.TRANSPARENT);
		border.setStroke(1, bold
		? Color.parseColor("#BBDEFB")  // header border
		: Color.parseColor("#90CAF9")); // body border
		tv.setBackground(border);
		
		float density = getResources().getDisplayMetrics().density;
		tv.setLayoutParams(new TableRow.LayoutParams(
		(int)(widthDp * density),
		(int)(ROW_HEIGHT * density)
		));
		
		if (bold) tv.setTypeface(null, Typeface.BOLD);
		
		return tv;
	}
}
